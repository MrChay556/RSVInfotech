export const achievements = [
  {
    value: "20+",
    label: "Years Experience",
    description: "Two decades of delivering exceptional IT solutions to businesses of all sizes."
  },
  {
    value: "100+",
    label: "Happy Clients",
    description: "Trusted by over a hundred businesses across Singapore and beyond."
  },
  {
    value: "24/7",
    label: "Support",
    description: "Round-the-clock technical support and monitoring for your peace of mind."
  }
];
